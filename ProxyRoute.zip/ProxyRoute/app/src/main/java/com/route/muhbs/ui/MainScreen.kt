package com.route.muhbs.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.route.muhbs.service.ProxyForegroundService
import com.route.muhbs.util.Constants

@Composable
fun MainScreen() {
val ctx = LocalContext.current
var running by remember { mutableStateOf(false) }
var interval by remember { mutableStateOf(60f) }

Column(
modifier = Modifier
.fillMaxSize()
.padding(24.dp)
.verticalScroll(rememberScrollState()),
horizontalAlignment = Alignment.CenterHorizontally
) {
Spacer(Modifier.height(32.dp))
Text("🌐 ProxyRoute", style = MaterialTheme.typography.headlineMedium)
Spacer(Modifier.height(8.dp))
Text(
"Local HTTP Proxy + Auto-Rotasi",
style = MaterialTheme.typography.bodyMedium
)

Spacer(Modifier.height(32.dp))

Card(modifier = Modifier.fillMaxWidth()) {
Column(Modifier.padding(16.dp)) {
Text("Status", style = MaterialTheme.typography.titleMedium)
Spacer(Modifier.height(8.dp))
Text(if (running) "🟢 AKTIF" else "🔴 NONAKTIF",
style = MaterialTheme.typography.bodyLarge)
Spacer(Modifier.height(8.dp))
Text(
"Proxy: 127.0.0.1:${Constants.LOCAL_PROXY_PORT}",
fontFamily = FontFamily.Monospace
)
}
}

Spacer(Modifier.height(16.dp))

Card(modifier = Modifier.fillMaxWidth()) {
Column(Modifier.padding(16.dp)) {
Text("Interval Rotasi: ${interval.toInt()}s",
style = MaterialTheme.typography.titleMedium)
Slider(
value = interval,
onValueChange = { interval = it },
valueRange = 10f..600f,
steps = 58
)
Text("Min 10s, Max 600s", style = MaterialTheme.typography.bodySmall)
}
}

Spacer(Modifier.height(24.dp))

Button(
onClick = {
if (!running) {
val i = Intent(ctx, ProxyForegroundService::class.java).apply {
putExtra("interval", interval.toLong())
}
ContextCompat.startForegroundService(ctx, i)
} else {
ctx.stopService(Intent(ctx, ProxyForegroundService::class.java))
}
running = !running
},
modifier = Modifier.fillMaxWidth().height(56.dp)
) {
Text(if (running) "⏹  STOP" else "▶  START")
}

Spacer(Modifier.height(24.dp))

Card(modifier = Modifier.fillMaxWidth()) {
Column(Modifier.padding(16.dp)) {
Text("📖 Cara Pakai", style = MaterialTheme.typography.titleMedium)
Spacer(Modifier.height(8.dp))
Text(
"1. Klik START\n" +
"2. Tunggu fetch & validasi proxy\n" +
"3. Set proxy WiFi/App ke:\n" +
"   127.0.0.1:8080\n" +
"4. Proxy akan rotasi otomatis",
style = MaterialTheme.typography.bodySmall
)
}
}

Spacer(Modifier.height(16.dp))

Text(
"⚠️ Proxy publik gratis — jangan pakai untuk login/transaksi.",
style = MaterialTheme.typography.bodySmall,
color = MaterialTheme.colorScheme.error
)

Spacer(Modifier.height(32.dp))
}
}