package com.route.muhbs.data

import androidx.room.*

@Dao
interface ProxyDao {
@Insert(onConflict = OnConflictStrategy.REPLACE)
suspend fun insertAll(proxies: List<ProxyEntity>)

@Query("SELECT * FROM proxies WHERE alive = 1 AND fails < 5 ORDER BY latencyMs ASC")
suspend fun getAlive(): List<ProxyEntity>

@Query("SELECT * FROM proxies ORDER BY latencyMs ASC LIMIT :limit")
suspend fun getAll(limit: Int = 500): List<ProxyEntity>

@Query("SELECT COUNT(*) FROM proxies")
suspend fun count(): Int

@Query("SELECT COUNT(*) FROM proxies WHERE alive = 1")
suspend fun aliveCount(): Int

@Query("UPDATE proxies SET fails = fails + 1 WHERE address = :addr")
suspend fun markFail(addr: String)

@Query("DELETE FROM proxies WHERE fails >= 20")
suspend fun prune()

@Query("DELETE FROM proxies")
suspend fun clear()
}