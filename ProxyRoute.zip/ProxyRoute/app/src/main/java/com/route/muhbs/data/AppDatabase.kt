package com.route.muhbs.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ProxyEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
abstract fun proxyDao(): ProxyDao

companion object {
@Volatile private var INSTANCE: AppDatabase? = null
fun get(ctx: Context): AppDatabase =
INSTANCE ?: synchronized(this) {
INSTANCE ?: Room.databaseBuilder(ctx, AppDatabase::class.java, "proxyroute.db")
.fallbackToDestructiveMigration()
.build().also { INSTANCE = it }
}
}
}