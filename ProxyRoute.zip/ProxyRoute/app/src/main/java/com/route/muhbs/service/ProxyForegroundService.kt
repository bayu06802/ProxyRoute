package com.route.muhbs.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.route.muhbs.MainActivity
import com.route.muhbs.core.LocalProxyServer
import com.route.muhbs.core.ProxyPool
import com.route.muhbs.core.ProxyRotator
import com.route.muhbs.util.Constants
import kotlinx.coroutines.*

class ProxyForegroundService : Service() {

private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
private var server: LocalProxyServer? = null
private var rotationJob: Job? = null
private val rotator = ProxyRotator()
private lateinit var pool: ProxyPool

override fun onCreate() {
super.onCreate()
pool = ProxyPool(applicationContext)
}

override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
val intervalSec = intent?.getLongExtra("interval", 60L) ?: 60L
startForeground(Constants.NOTIF_ID, buildNotif("Menyiapkan..."))

scope.launch {
// Refresh pool dulu
updateNotif("Fetch & validasi proxy...")
val alive = pool.refresh { msg -> updateNotif(msg) }
updateNotif("Aktif • $alive proxy • rotasi ${intervalSec}s")

// Start local proxy server
server = LocalProxyServer(
port = Constants.LOCAL_PROXY_PORT,
onRotation = {
val list = pool.getAllAlive()
rotator.rotate(list)
},
onFail = { p -> pool.markFail(p.address) }
).also { it.start() }

// Rotation loop
rotationJob?.cancel()
rotationJob = launch {
while (isActive) {
delay(intervalSec * 1000)
val list = pool.getAllAlive()
val next = rotator.rotate(list)
next?.let {
updateNotif("Rotasi → ${it.address} (${it.latencyMs}ms) • ${list.size} pool")
}
}
}
}
return START_STICKY
}

private fun updateNotif(text: String) {
val mgr = getSystemService(NotificationManager::class.java)
mgr.notify(Constants.NOTIF_ID, buildNotif(text))
}

private fun buildNotif(text: String): Notification {
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
val mgr = getSystemService(NotificationManager::class.java)
if (mgr.getNotificationChannel(Constants.CHANNEL_ID) == null) {
mgr.createNotificationChannel(
NotificationChannel(
Constants.CHANNEL_ID, "ProxyRoute",
NotificationManager.IMPORTANCE_LOW
)
)
}
}
val pi = PendingIntent.getActivity(
this, 0, Intent(this, MainActivity::class.java),
PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)
return NotificationCompat.Builder(this, Constants.CHANNEL_ID)
.setContentTitle("ProxyRoute aktif di 127.0.0.1:${Constants.LOCAL_PROXY_PORT}")
.setContentText(text)
.setSmallIcon(android.R.drawable.stat_sys_upload)
.setContentIntent(pi)
.setOngoing(true)
.build()
}

override fun onDestroy() {
rotationJob?.cancel()
server?.stop()
scope.cancel()
super.onDestroy()
}

override fun onBind(intent: Intent?): IBinder? = null
}