package com.route.muhbs.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "proxies")
data class ProxyEntity(
@PrimaryKey val address: String,
val scheme: String,
val latencyMs: Long = -1,
val fails: Int = 0,
val lastChecked: Long = 0,
val alive: Boolean = false
)