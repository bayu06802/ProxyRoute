package com.route.muhbs.core

import android.util.Log
import com.route.muhbs.data.ProxyEntity
import kotlinx.coroutines.*
import java.io.*
import java.net.*

class LocalProxyServer(
private val port: Int,
private val onRotation: suspend () -> ProxyEntity?,
private val onFail: suspend (ProxyEntity) -> Unit
) {
private var serverSocket: ServerSocket? = null
private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
@Volatile private var currentProxy: ProxyEntity? = null

fun start() {
scope.launch {
try {
serverSocket = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
Log.i("LocalProxy", "Listening on 127.0.0.1:$port")
while (isActive) {
val client = serverSocket?.accept() ?: break
launch { handleClient(client) }
}
} catch (e: Exception) {
Log.e("LocalProxy", "Server error", e)
}
}
}

fun stop() {
runCatching { serverSocket?.close() }
scope.cancel()
}

private suspend fun handleClient(client: Socket) {
try {
client.soTimeout = 15000
val input = BufferedInputStream(client.getInputStream())
val output = BufferedOutputStream(client.getOutputStream())

// Baca request line
val requestLine = readLine(input) ?: return
val parts = requestLine.split(" ")
if (parts.size < 3) return

val method = parts[0]
val url = parts[1]

// Baca headers
val headers = StringBuilder()
while (true) {
val line = readLine(input) ?: break
if (line.isEmpty()) break
headers.append(line).append("\r\n")
}

if (method == "CONNECT") {
handleHttpsTunnel(client, url, output)
} else {
handleHttp(client, method, url, headers.toString(), output)
}
} catch (e: Exception) {
Log.w("LocalProxy", "Client error: ${e.message}")
} finally {
runCatching { client.close() }
}
}

/** HTTPS via CONNECT tunnel */
private suspend fun handleHttpsTunnel(client: Socket, hostPort: String, output: BufferedOutputStream) {
val proxy = currentProxy ?: onRotation()?.also { currentProxy = it } ?: return
try {
val (proxyHost, proxyPort) = proxy.address.split(":")
val upstream = Socket()
upstream.connect(InetSocketAddress(proxyHost, proxyPort.toInt()), 8000)

// Kirim CONNECT ke upstream proxy
val connectReq = "CONNECT $hostPort HTTP/1.1\r\nHost: $hostPort\r\n\r\n"
upstream.getOutputStream().write(connectReq.toByteArray())
upstream.getOutputStream().flush()

// Baca respon dari proxy
val upIn = BufferedInputStream(upstream.getInputStream())
val respLine = readLine(upIn) ?: return
while (true) {
val l = readLine(upIn) ?: break
if (l.isEmpty()) break
}

if (!respLine.contains("200")) {
output.write("HTTP/1.1 502 Bad Gateway\r\n\r\n".toByteArray())
output.flush()
upstream.close()
onFail(proxy)
currentProxy = null
return
}

// Konfirmasi ke client
output.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
output.flush()

// Pipe bidirectional
scope.launch {
try { client.getInputStream().copyTo(upstream.getOutputStream()) } catch (_: Exception) {}
runCatching { upstream.shutdownOutput() }
}
try { upstream.getInputStream().copyTo(output) } catch (_: Exception) {}

upstream.close()
} catch (e: Exception) {
Log.w("LocalProxy", "Tunnel error: ${e.message}")
onFail(proxy)
currentProxy = null
runCatching { output.write("HTTP/1.1 502 Bad Gateway\r\n\r\n".toByteArray()) }
}
}

/** HTTP plain */
private suspend fun handleHttp(
client: Socket, method: String, url: String,
headers: String, output: BufferedOutputStream
) {
val proxy = currentProxy ?: onRotation()?.also { currentProxy = it } ?: return
try {
val uri = URI(url)
val path = if (uri.rawPath.isNullOrEmpty()) "/" else uri.rawPath +
(uri.rawQuery?.let { "?$it" } ?: "")

val (proxyHost, proxyPort) = proxy.address.split(":")
val upstream = Socket()
upstream.connect(InetSocketAddress(proxyHost, proxyPort.toInt()), 8000)

val sb = StringBuilder()
sb.append("$method $url HTTP/1.1\r\n")
sb.append(headers)
sb.append("\r\n")

upstream.getOutputStream().write(sb.toString().toByteArray())
upstream.getOutputStream().flush()

upstream.getInputStream().copyTo(output)
upstream.close()
} catch (e: Exception) {
Log.w("LocalProxy", "HTTP error: ${e.message}")
onFail(proxy)
currentProxy = null
runCatching { output.write("HTTP/1.1 502 Bad Gateway\r\n\r\n".toByteArray()) }
}
}

private fun readLine(input: InputStream): String? {
val buf = ByteArrayOutputStream()
var prev = -1
while (true) {
val b = input.read()
if (b == -1) return if (buf.size() == 0) null else buf.toString("ISO-8859-1")
if (b == '\n'.code && prev == '\r'.code) {
val s = buf.toString("ISO-8859-1")
return s.dropLast(1)
}
buf.write(b)
prev = b
}
}
}