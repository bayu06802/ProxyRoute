package com.route.muhbs.core

import android.content.Context
import com.route.muhbs.data.AppDatabase
import com.route.muhbs.data.ProxyEntity

class ProxyPool(private val ctx: Context) {
private val dao = AppDatabase.get(ctx).proxyDao()

suspend fun refresh(onProgress: (String) -> Unit = {}): Int {
onProgress("Fetching dari 20 sumber...")
val fetched = ProxyFetcher().fetchAll()
onProgress("Dapat ${fetched.size} proxy, validasi...")

val validated = ProxyValidator().validate(fetched)
val alive = validated.filter { it.alive }
onProgress("Hidup: ${alive.size}/${fetched.size}")

dao.clear()
dao.insertAll(validated)
return alive.size
}

suspend fun aliveCount(): Int = dao.aliveCount()
suspend fun totalCount(): Int = dao.count()
suspend fun getAllAlive(): List<ProxyEntity> = dao.getAlive()
suspend fun markFail(addr: String) = dao.markFail(addr)
suspend fun prune() = dao.prune()
}