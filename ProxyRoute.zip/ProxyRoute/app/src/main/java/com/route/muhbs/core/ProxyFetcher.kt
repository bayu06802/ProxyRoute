package com.route.muhbs.core

import android.util.Log
import com.route.muhbs.data.ProxyEntity
import com.route.muhbs.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class ProxyFetcher {
private val client = OkHttpClient.Builder()
.connectTimeout(Constants.FETCH_TIMEOUT_MS, TimeUnit.MILLISECONDS)
.readTimeout(Constants.FETCH_TIMEOUT_MS, TimeUnit.MILLISECONDS)
.build()

suspend fun fetchAll(): List<ProxyEntity> = withContext(Dispatchers.IO) {
val regex = Regex("""(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})""")
val result = mutableListOf<ProxyEntity>()

coroutineScope {
Constants.PROXY_SOURCES.map { url ->
async {
runCatching {
val req = Request.Builder().url(url).build()
client.newCall(req).execute().use { resp ->
if (!resp.isSuccessful) return@async emptyList<ProxyEntity>()
val body = resp.body?.string().orEmpty()
val scheme = when {
url.contains("socks5", true) -> "socks5"
url.contains("socks4", true) -> "socks4"
else -> "http"
}
regex.findAll(body).map {
ProxyEntity(
address = "${it.groupValues[1]}:${it.groupValues[2]}",
scheme = scheme
)
}.toList()
}
}.getOrDefault(emptyList())
}
}.forEach { result += it.await() }
}
val distinct = result.distinctBy { it.address }
Log.i("ProxyFetcher", "Fetched ${distinct.size} proxies")
distinct
}
}