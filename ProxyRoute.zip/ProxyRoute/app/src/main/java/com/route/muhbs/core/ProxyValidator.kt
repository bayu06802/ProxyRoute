package com.route.muhbs.core

import com.route.muhbs.data.ProxyEntity
import com.route.muhbs.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

class ProxyValidator {
private val semaphore = Semaphore(50)

suspend fun validate(proxies: List<ProxyEntity>): List<ProxyEntity> = withContext(Dispatchers.IO) {
coroutineScope {
proxies.map { async { semaphore.withPermit { check(it) } } }
.map { it.await() }
}
}

private fun check(p: ProxyEntity): ProxyEntity {
val type = if (p.scheme.startsWith("socks")) Proxy.Type.SOCKS else Proxy.Type.HTTP
val host = p.address.substringBefore(":")
val port = p.address.substringAfter(":").toIntOrNull()
?: return p.copy(alive = false, fails = p.fails + 1)

val javaProxy = Proxy(type, InetSocketAddress(host, port))
val client = OkHttpClient.Builder()
.proxy(javaProxy)
.connectTimeout(Constants.VALIDATE_TIMEOUT_MS, TimeUnit.MILLISECONDS)
.readTimeout(Constants.VALIDATE_TIMEOUT_MS, TimeUnit.MILLISECONDS)
.build()

val start = System.currentTimeMillis()
return runCatching {
val req = Request.Builder().url(Constants.LIVENESS_URL).build()
client.newCall(req).execute().use { resp ->
if (resp.isSuccessful) p.copy(
alive = true,
latencyMs = System.currentTimeMillis() - start,
lastChecked = System.currentTimeMillis()
)
else p.copy(alive = false, fails = p.fails + 1)
}
}.getOrElse { p.copy(alive = false, fails = p.fails + 1) }
}
}