package com.route.muhbs.core

import com.route.muhbs.data.ProxyEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class ProxyRotator {
private val _current = MutableStateFlow<ProxyEntity?>(null)
val current: StateFlow<ProxyEntity?> = _current

private var index = 0

fun rotate(pool: List<ProxyEntity>): ProxyEntity? {
if (pool.isEmpty()) return null
index = (index + 1) % pool.size
return pool[index].also { _current.value = it }
}

fun set(p: ProxyEntity) { _current.value = p }
}