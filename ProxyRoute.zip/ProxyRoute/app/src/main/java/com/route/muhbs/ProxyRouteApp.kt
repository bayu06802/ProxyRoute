package com.route.muhbs

import android.app.Application

class ProxyRouteApp : Application()